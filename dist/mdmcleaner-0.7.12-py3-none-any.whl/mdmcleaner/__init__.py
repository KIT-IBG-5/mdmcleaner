#todo: rename lib folder to mdmcleaner
from mdmcleaner._version import __version__ as _version
__version__ = _version
